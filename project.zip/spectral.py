from kmeans import k_means_clustering
from numpy import linalg as LA
import numpy as np

def laplacian(A):
    """
    Calculate the Laplacian matrix of the affinity matrix A using the symmetric normalized Laplacian formulation.

    Parameters:
    - A: numpy array, affinity matrix capturing pairwise relationships between data points.

    Returns:
    - L_sym: numpy array, symmetric normalized Laplacian matrix.
    """

    # TODO: Calculate degree matrix

    # TODO: Calculate the inverse square root of the symmetric matrix

    # TODO: Return symmetric normalized Laplacian matrix

    pass

def spectral_clustering(affinity, k):
    """
    Perform spectral clustering on the given affinity matrix.

    Parameters:
    - affinity: numpy array, affinity matrix capturing pairwise relationships between data points.
    - k: int, number of clusters.

    Returns:
    - labels: numpy array, cluster labels assigned by the spectral clustering algorithm.
    """

    # TODO: Compute Laplacian matrix

    # TODO: Compute the first k eigenvectors of the Laplacian matrix

    # TODO: Apply K-means clustering on the selected eigenvectors

    # TODO: Return cluster labels

    pass
